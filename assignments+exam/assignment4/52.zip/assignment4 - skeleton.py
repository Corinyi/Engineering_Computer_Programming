def load_menu():
    Menu = []

    #========= STEP 1 ==========


    
    #========= STEP 1 ==========

    return Menu


def error_check(date):
    
    #========= STEP 3 ==========

    
    
    #========= STEP 3 ==========
        

def calculate_total_income(date):

    #========= STEP 4 ==========
    
    
    #========= STEP 4 ==========


MENU = load_menu()
while True:
    # load and error check
    date = input("The date of ledger file : ")

    #in error_check make 2 more files
    #   -> _corrected.txt and _name_error.txt
    error_check(date)
    calculate_total_income(date)             


    
